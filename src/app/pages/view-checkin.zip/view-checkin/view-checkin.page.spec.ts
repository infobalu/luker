import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewCheckinPage } from './view-checkin.page';

describe('ViewCheckinPage', () => {
  let component: ViewCheckinPage;
  let fixture: ComponentFixture<ViewCheckinPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewCheckinPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewCheckinPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
