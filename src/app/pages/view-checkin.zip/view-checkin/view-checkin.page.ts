import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-checkin',
  templateUrl: './view-checkin.page.html',
  styleUrls: ['./view-checkin.page.scss'],
})
export class ViewCheckinPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
